# Cbrain Claude Code Plugin 离线安装包

本包已包含 Claude Code Plugin 和安装器。安装过程不会访问 GitHub 或 npm；运行时需要访问 Cbrain Gateway。

要求：Node.js 22 或更高版本、已安装 Claude Code CLI，并已从 Cbrain 页面创建 API Key。

Windows PowerShell：

```powershell
.\install.ps1 -Gateway http://cbrain.example:8430
```

Linux、macOS 或 WSL：

```bash
chmod +x install.sh
./install.sh http://cbrain.example:8430
```

安装器会隐藏输入 API Key，验证身份并写入 `~/.hiper-agent-memory/config.json`。自动化安装可通过环境变量 `CBRAIN_API_KEY` 传入。安装完成后重启 Claude Code。升级时解压新版 ZIP 并重新执行安装脚本。
